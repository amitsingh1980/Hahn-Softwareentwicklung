﻿using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Domain
{
    public class HahnAppContext : DbContext
    {
        public HahnAppContext(DbContextOptions<HahnAppContext> options)
            : base(options)
        {
        }

        public DbSet<Applicant> Applicants { get; set; }
    }   
}

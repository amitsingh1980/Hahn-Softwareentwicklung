﻿using Hahn.ApplicatonProcess.May2020.Domain.Models;
using System.Collections.Generic;

namespace Hahn.ApplicatonProcess.May2020.Domain
{
    public class BaseData
    {
        private readonly HahnAppContext _context;
        public BaseData(HahnAppContext context)
        {
            this._context = context;
        }

        public void DataGenerator()
        {
            _context.Applicants.AddRange(Applicants());
            _context.SaveChanges();
        }

        private List<Applicant> Applicants()
        {
            List<Applicant> _applicants = new List<Applicant>();
            Applicant valCheck = new Applicant()
            {
                Address = "Random Address One",
                Age = 27,
                CountryOfOrigin = "IND",
                EmailAddress = "abc@xyz.com",
                FamilyName = "POne",
                Hired = true,
                Name = "Person One"
            };
            _applicants.Add(valCheck);

            valCheck = new Applicant()
            {
                Address = "Random Address Two",
                Age = 36,
                CountryOfOrigin = "IND",
                EmailAddress = "a13dbc@xyz.com",
                FamilyName = "PTwo",
                Hired = true,
                Name = "Person Two"
            };
            _applicants.Add(valCheck);

            return _applicants;
        }

    }
}

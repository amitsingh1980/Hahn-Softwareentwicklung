﻿using System;

namespace Hahn.ApplicatonProcess.May2020.Domain.Models
{
    public class JWTSettings
    {
        public string ApiSecretKey { get; set; }
        public string ResourceId { get; set; }
        public string InstanceId { get; set; }
        public int TokenExpiryInMinutes { get; set; }
    }
}

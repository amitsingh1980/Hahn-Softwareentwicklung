﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net.Http;
using System.Text;

namespace Hahn.ApplicatonProcess.May2020.Domain.Models
{
    public class ApplicantValidator : AbstractValidator<Applicant>
    {
        public ApplicantValidator() {
            RuleFor(x => x.Name).Length(5, 100).NotNull().NotEmpty();
            RuleFor(x => x.FamilyName).Length(5, 100).NotNull().NotEmpty();
            RuleFor(x => x.Address).Length(10, 500).NotNull().NotEmpty();
            RuleFor(x => x.CountryOfOrigin).NotNull().NotEmpty().MustAsync(async (ctry, cancellation) =>
            {
                string remoteValidationUrl = "https://restcountries.eu/rest/v2/name/" + ctry + "? fullText=true";
                using (HttpClient http = new HttpClient())
                {
                    var message = await http.GetAsync(remoteValidationUrl);
                    if (message.StatusCode != System.Net.HttpStatusCode.OK)
                    {
                        return false;
                    }
                }
                return true;
            }).WithMessage("Country of Origin is not valid");
            RuleFor(x => x.EmailAddress).EmailAddress().NotEmpty().NotNull();
            RuleFor(x => x.Age).InclusiveBetween(20, 60);
            RuleFor(x => x.Hired).InclusiveBetween(false, true);
        }
    }
}

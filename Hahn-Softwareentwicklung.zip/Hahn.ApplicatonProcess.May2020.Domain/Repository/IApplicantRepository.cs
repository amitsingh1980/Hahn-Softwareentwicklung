﻿using Hahn.ApplicatonProcess.May2020.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Domain.Repository
{
    public interface IApplicantRepository
    {
        Task<IEnumerable<Applicant>> GetAllApplicants();

        Task<Applicant> GetApplicant(int id);

        Task<bool> SaveApplicant(Applicant applicant);

        Task<bool> UpdateApplicant(Applicant applicant);

        Task<bool> DeleteApplicant(int id);
    }
}

﻿using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Domain.Repository
{
    public class ApplicantRepository : IApplicantRepository
    {
        private HahnAppContext _context;
        public ApplicantRepository(HahnAppContext appContext)
        {
            this._context = appContext;
        }
        public async Task<bool> DeleteApplicant(int id)
        {
            var applicant = await _context.Applicants.FindAsync(id);
            int result = 0;
            if (applicant != null)
            {
                this._context.Applicants.Remove(applicant);
                result = await this._context.SaveChangesAsync();
                return result > 0 ? true : false;
            }
            else
            {
                return false;
            }
        }

        public async Task<IEnumerable<Applicant>> GetAllApplicants()
        {
            IEnumerable<Applicant> applicants = await _context.Applicants.ToListAsync();
            return applicants;
        }

        public async Task<Applicant> GetApplicant(int id)
        {
            Applicant applicant = await _context.Applicants.FindAsync(id);
            return applicant;
        }

        public async Task<bool> SaveApplicant(Applicant applicant)
        {
            this._context.Applicants.Add(applicant);
            int result = await this._context.SaveChangesAsync();
            return result > 0 ? true : false;
        }

        public async Task<bool> UpdateApplicant(Applicant applicant)
        {
            if (this.ApplicantExists(applicant.ID))
            {
                var dbStudent = await _context.Applicants.FirstOrDefaultAsync(s => s.ID.Equals(applicant.ID));
                dbStudent.Address = applicant.Address;
                dbStudent.Age = applicant.Age;
                dbStudent.CountryOfOrigin = applicant.CountryOfOrigin;
                dbStudent.EmailAddress = applicant.EmailAddress;
                dbStudent.FamilyName = applicant.FamilyName;
                dbStudent.Hired = applicant.Hired;
                dbStudent.Name = applicant.Name;

                this._context.Entry(dbStudent).State = EntityState.Modified;
                try
                {
                    int result = await this._context.SaveChangesAsync();
                    return result > 0 ? true : false;
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            else
                return false;
        }
        private bool ApplicantExists(int id)
        {
            return _context.Applicants.Any(e => e.ID == id);
        }
    }
}

﻿using FunctionalTests.Fixtures;
using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Hahn.ApplicatonProcess.May2020.Web;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace FunctionalTests
{
    public class ApplicantTests : BaseFixture
    {
        public ApplicantTests(WebApplicationFactory<Startup> factory):base(factory)
        {}

        [Fact]
        public async Task Test_Get_Checks()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants";

                // Act
                var response = await Client.GetAsync(request);

                // Assert
                response.EnsureSuccessStatusCode();
            }
        }

        [Fact]
        public async Task Test_Post_Applicants_EnsureSuccess()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants";

                var requestBody = new Applicant()
                {
                    Address = "Test address here",
                    Age = 25,
                    CountryOfOrigin = "IND",
                    EmailAddress = "abc@yahoo.com",
                    FamilyName = "User Family Name",
                    Hired = true,
                    Name = "User Name"
                };
                // Act
                var response = await Client.PostAsync(request, this.GetStringContent(requestBody));

                // Assert
                Assert.True(response.StatusCode == HttpStatusCode.Created);
            }
        }

        [Fact]
        public async Task Test_Post_Checks_EnsureBadRequest_Address()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants";

                var requestBody = new Applicant()
                {
                    Address = "Test",
                    Age = 25,
                    CountryOfOrigin = "IND",
                    EmailAddress = "abc@yahoo.com",
                    FamilyName = "User Family Name",
                    Hired = true,
                    Name = "User Name"
                };
                // Act
                var response = await Client.PostAsync(request, this.GetStringContent(requestBody));

                // Assert
                Assert.True(response.StatusCode == HttpStatusCode.BadRequest);
            }
        }

        [Fact]
        public async Task Test_Post_Checks_EnsureBadRequest_Age()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants";

                var requestBody = new Applicant()
                {
                    Address = "Test Address here",
                    Age = 17,
                    CountryOfOrigin = "IND",
                    EmailAddress = "abc@yahoo.com",
                    FamilyName = "User Family Name",
                    Hired = true,
                    Name = "User Name"
                };
                // Act
                var response = await Client.PostAsync(request, this.GetStringContent(requestBody));

                // Assert
                Assert.True(response.StatusCode == HttpStatusCode.BadRequest);
            }
        }

        [Fact]
        public async Task Test_Post_Checks_EnsureBadRequest_CountryOfOrigin()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants";

                var requestBody = new Applicant()
                {
                    Address = "Test Address here",
                    Age = 28,
                    CountryOfOrigin = "INzxadfdD",
                    EmailAddress = "abc@yahoo.com",
                    FamilyName = "User Family Name",
                    Hired = true,
                    Name = "User Name"
                };
                // Act
                var response = await Client.PostAsync(request, this.GetStringContent(requestBody));

                // Assert
                Assert.True(response.StatusCode == HttpStatusCode.BadRequest);
            }
        }

        [Fact]
        public async Task Test_Put_Applicant_Success()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants/1";

                var requestBody = new Applicant()
                {
                    ID = 1,
                    Address = "Test Address here",
                    Age = 28,
                    CountryOfOrigin = "USA",
                    EmailAddress = "abc@yahoo.com",
                    FamilyName = "User Family Name",
                    Hired = true,
                    Name = "User Name"
                };
                // Act
                var response = await Client.PutAsync(request, this.GetStringContent(requestBody));

                // Assert
                response.EnsureSuccessStatusCode();
            }
        }

        [Fact]
        public async Task Test_Put_Applicant_Failure()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants/1";

                var requestBody = new Applicant()
                {
                    ID = 50,
                    Address = "Test Address here",
                    Age = 28,
                    CountryOfOrigin = "USA",
                    EmailAddress = "abc@yahoo.com",
                    FamilyName = "User Family Name",
                    Hired = true,
                    Name = "User Name"
                };
                // Act
                var response = await Client.PutAsync(request, this.GetStringContent(requestBody));

                // Assert
                Assert.True(response.StatusCode == HttpStatusCode.BadRequest);
            }
        }

            [Fact]
        public async Task Test_Delete_Applicant()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants/1";

                // Act
                var response = await Client.DeleteAsync(request);

                // Assert
                response.EnsureSuccessStatusCode();
            }
        }

        [Fact]
        public async Task Test_Delete_Applicant_Failure()
        {
            using (var Client = _factory.CreateClient())
            {
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(this.MediaFormat));
                // Arrange
                var request = "/api/Applicants/500";

                // Act
                var response = await Client.DeleteAsync(request);

                // Assert
                Assert.True(response.StatusCode == HttpStatusCode.NotFound);
            }
        }
    }
}
﻿using Hahn.ApplicatonProcess.May2020.Web;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace FunctionalTests.Fixtures
{
    public class BaseFixture : IClassFixture<WebApplicationFactory<Startup>>
    {
        internal readonly WebApplicationFactory<Startup> _factory;
        internal readonly string MediaFormat = "application/json";
        public BaseFixture(
            WebApplicationFactory<Startup> factory)
        {
            _factory = factory;
        }

        public StringContent GetStringContent(object obj)
            => new StringContent(JsonConvert.SerializeObject(obj), Encoding.Default, this.MediaFormat);

    }
}

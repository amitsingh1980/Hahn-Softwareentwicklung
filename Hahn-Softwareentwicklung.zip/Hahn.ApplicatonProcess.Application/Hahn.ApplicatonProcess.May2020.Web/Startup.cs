using Aurelia.AspNetCore.SpaServices.AureliaCli.SpaServices.AureliaCli;
using FluentValidation;
using FluentValidation.AspNetCore;
using Hahn.ApplicatonProcess.May2020.Domain;
using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Hahn.ApplicatonProcess.May2020.Domain.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using System;
using System.IO;
using System.Linq;

[assembly: ApiConventionType(typeof(DefaultApiConventions))]
namespace Hahn.ApplicatonProcess.May2020.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options => options.AddPolicy("CorsAppPolicy", builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader().AllowAnyOrigin().AllowCredentials().Build()));
            services.AddDbContext<HahnAppContext>(opt =>
               opt.UseInMemoryDatabase(databaseName: "HahnApplicatonProcess"));
            services.AddMvc().AddFluentValidation();
            services.AddControllersWithViews();
            // In production, the Angular files will be served from this directory
            services.AddSpaStaticFiles(configuration =>
            {
                configuration.RootPath = "ClientApp/dist";
            });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Hahn.ApplicatonProcess.May2020.Web",
                    Version = "v1",
                    Description = "A Hahn.ApplicatonProcess.May2020.Web application built with ASP.net Core",
                    TermsOfService = new Uri("https://example.com/terms"),
                    Contact = new OpenApiContact
                    {
                        Name = "Amit Kumar Singh",
                        Email = string.Empty,
                        Url = new Uri("https://example.com/name"),
                    },
                    License = new OpenApiLicense
                    {
                        Name = "Use under LICX",
                        Url = new Uri("https://example.com/license"),
                    }
                });

                var xmlFile = "swaggerHahn_API.XML";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);

                //... and tell Swagger to use those XML comments.
                c.IncludeXmlComments(xmlPath);
                // Bearer token authentication
                //OpenApiSecurityScheme securityDefinition = new OpenApiSecurityScheme()
                //{
                //    Name = "Bearer",
                //    BearerFormat = "JWT",
                //    Scheme = "bearer",
                //    Description = "Specify the authorization token.",
                //    In = ParameterLocation.Header,
                //    Type = SecuritySchemeType.Http,
                //};
                //c.AddSecurityDefinition("jwt_auth", securityDefinition);

                // Make sure swagger UI requires a Bearer token specified
                //OpenApiSecurityScheme securityScheme = new OpenApiSecurityScheme()
                //{
                //    Reference = new OpenApiReference()
                //    {
                //        Id = "jwt_auth",
                //        Type = ReferenceType.SecurityScheme
                //    }
                //};
                //OpenApiSecurityRequirement securityRequirements = new OpenApiSecurityRequirement()
                //{
                //    {securityScheme, new string[] { }},
                //};
                //c.AddSecurityRequirement(securityRequirements);
                c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
            });

            services.AddScoped<ApplicantRepository>();
            services.AddTransient<IValidator<Applicant>, ApplicantValidator>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, HahnAppContext context)
        {

            app.UseSwagger();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            if (!env.IsDevelopment())
            {
                app.UseSpaStaticFiles();
            }

            app.UseRouting();
            //app.UseAuthentication();
            //app.UseAuthorization();
            new BaseData(context).DataGenerator();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.Use(async (context, next) =>
            {
                context.Response.Headers.Remove("server");
                context.Response.Headers.Remove("x-powered-by");
                await next();
            });


            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
                c.InjectStylesheet("/css/swagger.min.css");
                c.RoutePrefix = "swagger";
            });

            app.UseSpa(spa =>
            {
                // To learn more about options for serving an Angular SPA from ASP.NET Core,
                // see https://go.microsoft.com/fwlink/?linkid=864501

                spa.Options.SourcePath = "ClientApp";

                if (env.IsDevelopment())
                {
                   spa.UseAureliaCliServer("start");
                }
            });

        }
    }
}

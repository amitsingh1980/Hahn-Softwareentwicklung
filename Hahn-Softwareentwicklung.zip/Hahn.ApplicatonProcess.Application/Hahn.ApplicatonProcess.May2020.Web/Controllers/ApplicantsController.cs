﻿using Hahn.ApplicatonProcess.May2020.Domain.Models;
using Hahn.ApplicatonProcess.May2020.Domain.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.May2020.Web.Controllers
{
    [Route("api/[controller]")]
    [Produces("application/json")]
    [ApiController]
    [ApiConventionType(typeof(DefaultApiConventions))]
    public class ApplicantsController : BaseController<ApplicantsController>
    {
        private readonly ApplicantRepository _applicantRepository;

        public ApplicantsController(ApplicantRepository applicantRepository, ILogger<ApplicantsController> logger) : base(logger)
        {
            _applicantRepository = applicantRepository;
        }

        // GET: api/Applicants
        [NonAction]
        public async Task<ActionResult<IEnumerable<Applicant>>> GetApplicants()
        {
            return Ok(await _applicantRepository.GetAllApplicants());
        }

        /// <summary>
        /// Returns an applicant by Integer Id.
        /// </summary>
        /// <remarks>
        /// All requests require Authorization header JWT token. Configure token from api/Token.
        /// GET: api/Applicants/5
        /// </remarks>
        /// <param name="id" example="1">Applicant Id</param>
        /// <returns>An applicant data with HTTP Status 200</returns>
        /// <response code="200">Success if checks are fetched.</response>
        /// <response code="404">Not Found - if application is not found.</response>
        /// <response code="500">Server Error if there's an unhandled exception.</response>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<Applicant>> GetApplicant(int id)
        {
            this._logger.LogInformation("Get Applicant started with ID " + Convert.ToString(id));
            Applicant applicant = await _applicantRepository.GetApplicant(id);

            if (applicant == null)
            {
                _logger.LogError("ID Not Found");
                return NotFound();
            }

            return Ok(applicant);
        }

        /// <summary>
        /// Saves an applicant by Integer Id, applicant data is received from body of the request.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     PUT /Applicant
        ///     {
        ///     "id": 1,
        ///     "name": "Person OneWay",
        ///     "familyName": "POneWay",
        ///     "address": "Random Address Of person One",
        ///     "countryOfOrigin": "USA",
        ///     "emailAddress": "abc@xyz.com",
        ///     "age": 32,
        ///     "hired": true
        ///     }
        ///
        /// </remarks>
        /// <param name="id" example="1">Applicant Id</param>
        /// <param name="applicant" example="Applicant">Applicant Data</param>
        /// <returns>An applicant data with HTTP Status 200</returns>
        /// <response code="200">Success if checks are fetched.</response>
        /// <response code="404">Bad Request if application is not found.</response>
        /// <response code="500">Server Error if there's an unhandled exception.</response>
        // PUT: api/Applicants/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> PutApplicant(int id, [FromBody]Applicant applicant)
        {
            this._logger.LogInformation("Put Applicant started with ID " + Convert.ToString(id));
            var validator = new ApplicantValidator();
            var result = await validator.ValidateAsync(applicant);
            if (!result.IsValid)
                return BadRequest();
            if (id != applicant.ID)
            {
                _logger.LogError("ID Not matching between postdata and Url");
                return BadRequest();
            }
            try 
            {
                await _applicantRepository.UpdateApplicant(applicant);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest();
            }
            return Ok();
        }

        /// <summary>
        /// Saves an applicant, applicant data is received from body of the request.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /Applicant
        ///     {
        ///     "id": 0,
        ///     "name": "Person Five",
        ///     "familyName": "PFive",
        ///     "address": "Random Address Of person Five",
        ///     "countryOfOrigin": "IND",
        ///     "emailAddress": "abc@xyz.com",
        ///     "age": 28,
        ///     "hired": true
        ///     }
        ///
        /// </remarks>
        /// <param name="applicant" example="Applicant">Applicant Data</param>
        /// <returns>An applicant data with HTTP Status 200</returns>
        /// <response code="200">Success if checks are fetched.</response>
        /// <response code="404">Bad Request if application is not found.</response>
        /// <response code="500">Server Error if there's an unhandled exception.</response>
        // POST: api/Applicants
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<Applicant>> PostApplicant(Applicant applicant)
        {
            this._logger.LogInformation("Put Applicant started with new applicant ");
            var validator = new ApplicantValidator();
            var result = await validator.ValidateAsync(applicant);
            if (!result.IsValid)
            {
                this._logger.LogError("Validation failed - " + JsonConvert.SerializeObject(result.Errors));
                return BadRequest();
            }
            try
            {
                await _applicantRepository.SaveApplicant(applicant);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest();
            }
            return CreatedAtAction("PostApplicant", new { id = applicant.ID }, applicant);
        }

        [HttpGet("CountryCodes")]
        [NonAction]
        public async Task<ActionResult<CountryCodes>> GetCountries()
        {
            using (HttpClient client = new HttpClient())
            { 
                HttpResponseMessage message = await client.GetAsync("https://restcountries.eu/rest/v2/all");
                string json = await message.Content.ReadAsStringAsync();
                List<CountryCodes> countryCodes = JsonConvert.DeserializeObject<List<CountryCodes>>(json);
                return Ok(countryCodes);
            }
        }

        /// <summary>
        /// Deletes an applicant by ID.
        /// </summary>
        /// <remarks>
        /// All requests require Authorization header JWT token. Configure token from api/Token.
        /// DELETE: api/Applicants/5
        /// </remarks>
        /// <param name="id" example="1">Applicant Id</param>
        /// <returns>An applicant data with HTTP Status 200</returns>
        /// <response code="200">Success if checks are fetched.</response>
        /// <response code="400">Bad Request if application is not found.</response>
        /// <response code="404">Not found if application is not found.</response>
        /// <response code="500">Server Error if there's an unhandled exception.</response>
        // DELETE: api/Applicants/5
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<bool>> DeleteApplicant(int id)
        {
            this._logger.LogInformation("Delete Applicant started with applicant ID " + Convert.ToString(id));
            try
            {
                var result = await _applicantRepository.DeleteApplicant(id);
                if (!result) {
                    this._logger.LogError("Delete Applicant failed for ID " + Convert.ToString(id));
                    return NotFound();
                }
            }
            catch (Exception) {
                return BadRequest();
            }
            return Ok();
        }

        
    }
}

﻿using Hahn.ApplicatonProcess.May2020.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;


namespace Hahn.ApplicatonProcess.May2020.Web.Controllers
{
    public class BaseController<T> : ControllerBase where T : class
    {
        protected internal readonly ILogger<T> _logger;
        public BaseController(ILogger<T> logger)
        {
            _logger = logger;
        }
    }
}

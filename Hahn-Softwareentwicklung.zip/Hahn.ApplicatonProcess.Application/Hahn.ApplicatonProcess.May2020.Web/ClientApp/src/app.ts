import { PLATFORM } from "aurelia-framework";
import { I18N } from 'aurelia-i18n';
export class App {
  public router: any;
  i18n: any;
  static inject = [I18N];
  constructor(i18n) {
    this.i18n = i18n;
    this.i18n
      .setLocale('de')
      .then(() => {
      });
  }
  configureRouter(config, router) {
    this.router = router;

    config.title = 'Applicants';
    config.map([
      { route: '', name: 'ApplicantInfo', moduleId: PLATFORM.moduleName('ApplicantInfo'), title: 'Applicant' },
      { route: 'result', name: 'Result', moduleId: PLATFORM.moduleName('result'), nav: false, title: 'Result' }
    ]);
  }
}

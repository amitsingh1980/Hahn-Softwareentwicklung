
export class SimpleForm {

  currentRecord = {
    firstName: "John",
    lastName: "Doe",
    email: "john@doe.com"
  };

 submit() {
   console.log('submitting...');
 } 
}
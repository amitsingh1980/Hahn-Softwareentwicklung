import 'jQuery';
import 'bootstrap';

export class App {

  message = 'Hello World!';
}
export class NoSelection {
  message: string;
  
  constructor() {
    this.message = "No Selection - Home page.";
  }
}

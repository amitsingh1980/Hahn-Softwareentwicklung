"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var aurelia_framework_1 = require("aurelia-framework");
var aurelia_i18n_1 = require("aurelia-i18n");
var App = /** @class */ (function () {
    function App(i18n) {
        this.i18n = i18n;
        this.i18n
            .setLocale('de')
            .then(function () {
        });
    }
    App.prototype.configureRouter = function (config, router) {
        this.router = router;
        config.title = 'Applicants';
        config.map([
            { route: '', name: 'ApplicantInfo', moduleId: aurelia_framework_1.PLATFORM.moduleName('ApplicantInfo'), title: 'Applicant' },
            { route: 'result', name: 'Result', moduleId: aurelia_framework_1.PLATFORM.moduleName('result'), nav: false, title: 'Result' }
        ]);
    };
    App.inject = [aurelia_i18n_1.I18N];
    return App;
}());
exports.App = App;
//# sourceMappingURL=app.js.map
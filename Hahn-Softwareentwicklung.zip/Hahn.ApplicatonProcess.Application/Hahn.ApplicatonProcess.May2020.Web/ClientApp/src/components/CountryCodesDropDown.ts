import { HttpClient } from 'aurelia-http-client';
import { observable } from 'aurelia-framework';

export class CountryCodesDropDown {
  selectedCountryCode: string;
  @observable countryCodes: [];
    http: any;

  constructor() {
    this.http = new HttpClient();
    
  }

  activate(params) {
    return Promise.all([
      this.http.get('http://localhost:60000/api/Applicants/CountryCodes').then(http => {
        this.countryCodes = JSON.parse(http.response);
      })
    ]);
  }
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var aurelia_fetch_client_1 = require("aurelia-fetch-client");
var CountryCodesDropDown = /** @class */ (function () {
    function CountryCodesDropDown() {
        var _this = this;
        var httpClient = new aurelia_fetch_client_1.HttpClient();
        httpClient.fetch("http://localhost:60000/api/Applicants/CountryCodes")
            .then(function (response) { return response.json(); })
            .then(function (response) { return _this.countryCodes = response; })
            .then(function (response) { return console.log(_this.countryCodes); });
    }
    return CountryCodesDropDown;
}());
exports.CountryCodesDropDown = CountryCodesDropDown;
//# sourceMappingURL=CountryCodesDropDown.js.map
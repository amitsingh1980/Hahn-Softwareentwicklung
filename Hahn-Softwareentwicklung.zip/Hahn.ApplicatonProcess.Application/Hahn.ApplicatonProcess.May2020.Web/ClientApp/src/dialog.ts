﻿import {DOM} from 'aurelia-framework';
// https://github.com/aurelia/dialog/issues/183
export function vCenterWithBodyObserver(modalContainer: HTMLElement) {
    const wrapper = <HTMLElement>modalContainer.children[0];
    recenter(wrapper);
    let observer = new MutationObserver(() => recenter(wrapper));
    observer.observe(modalContainer.querySelector("ai-dialog-body"), { attributes: true, childList: true });
}

function recenter(element: HTMLElement) {
    const vh = Math.max((<HTMLElement>DOM.querySelectorAll('html')[0]).clientHeight, window.innerHeight || 0);
    element.style.marginTop = Math.max(((vh - element.offsetHeight) / 2), 30) + 'px';
}

import { inject, NewInstance } from 'aurelia-framework';
import { ValidationController, ValidationControllerFactory, ValidationRules, validateTrigger } from 'aurelia-validation';
import { BootstrapFormRenderer } from './bootstrap-form-renderer'; //import the validation renderer
import { DialogService } from 'aurelia-dialog';
import { Modal } from './components/modal';
import { CountryCodesDropDown } from './components/CountryCodesDropDown';
import { ApplicantsClient, Applicant } from './applicantsApi';
import { App } from './app';
import { Router } from 'aurelia-router';
import { vCenterWithBodyObserver } from "./dialog";
import { I18N } from 'aurelia-i18n';

@inject(NewInstance.of(ValidationController), DialogService, ApplicantsClient, Router, I18N)
export class ApplicantInfo {
  controller: any;
  dialogService: any;

  api: ApplicantsClient;
  Name: string = '';
  FamilyName: string = '';
  Address: string = '';
  CountryOfOrigin: string = '';
  EmailAddress: string = '';
  Age: number = 0;
  Hired: boolean = false;
  routeConfig: any;
  router: any;
  i18N: any;

  constructor(controller, dialog, api: ApplicantsClient, router: Router, i18n) {
    this.controller = controller;
    this.i18N = i18n;
    this.controller.addRenderer(new BootstrapFormRenderer()); //configure the validation renderer
    this.controller.validateTrigger = validateTrigger.manual;
    this.configureValidationRules(); //configure the validation rules
    this.dialogService = dialog;
    this.api = api;
    this.router = router;
  }
  activate(params, routeConfig) {
    this.routeConfig = routeConfig;
  }

  canSend() {
    this.controller.validate().then(result => {
      return result.valid;
    });
  }

  canReset() {
    let condition = ((this.Name != "")
      || (this.FamilyName != "")
      || (this.Address != "")
      || (this.CountryOfOrigin != "")
      || (this.EmailAddress != "")
      || (this.Age > -1)
      || (this.Hired != null));
    return condition;
  }

  openModal() {
    if (this.canReset()) {
      let message = this.i18N.tr("ResetText");
      if (!message)
        message = 'Are you sure to reset all the data?';


      this.dialogService.open({
        viewModel: Modal,
        model: message,
        position: vCenterWithBodyObserver
      }).whenClosed(response => {
        if (!response.wasCancelled) {
          this.Address = "";
          this.Age = 0;
          this.Hired = false;
          this.CountryOfOrigin = "";
          this.EmailAddress = "";
          this.FamilyName = "";
          this.Name = "";
        } else {
        }
      });
    }
  }

  configureValidationRules() {


    ValidationRules
      .ensure('Name').required().satisfies(value => ((value.length > 5) && (value.length < 100))).withMessage("InvalidName")
      .ensure('FamilyName').required().satisfies(value => ((value.length > 5) && (value.length < 100))).withMessage("InvalidFamilyName")
      .ensure('Address').required().satisfies(value => ((value.length > 10) && (value.length < 100)))
      .ensure('CountryOfOrigin').required().satisfies(value => ((value.length == 3)))
      .ensure('EmailAddress').required().email()
      .ensure('Age').required().between(19, 61)
      .ensure('Hired').required()
      .on(this);
  }

  send() {
    this.controller.validate().then(result => {
      if (result.valid) {
        const applicant = new Applicant();
        applicant.ID = 0;
        applicant.Name = this.Name;
        applicant.FamilyName = this.FamilyName;
        applicant.Address = this.Address;
        applicant.Age = this.Age;
        applicant.CountryOfOrigin = this.CountryOfOrigin;
        applicant.EmailAddress = this.EmailAddress;
        applicant.Hired = this.Hired;
        console.log(applicant);
        try {
          this.api.postApplicant(applicant).then(response => {

            this.routeConfig.navModel.setTitle(response.Name);
          }).catch(response => {
            if (response.status == 201) {
              this.router.navigate("result");
            }
            else {
              let message = JSON.parse(response.response);

              this.dialogService.open({
                viewModel: Modal,
                model: JSON.stringify(message.errors),
                position: vCenterWithBodyObserver
              }).whenClosed(response => {
                if (!response.wasCancelled) {
                } else {
                }
              });
            }
          });
        }
        catch (err) {

        }
        //this.controller.reset();
      } else {
      }
    });
  }
}

